
#include "sprites.hpp"

#include <random>

#ifdef SCENE_PARTICLES_TRAJECTORY_SPRITES

using namespace vcl;



void scene_model::load_decoration_meshes(GLuint shader)
{
    cooking_pot                = mesh_load_file_obj("scenes/sources/particles_trajectory/sprites/assets/cauldron.obj");
    cooking_pot.shader         = shader;
    cooking_pot.uniform.color  = {0.9f, 0.8f, 0.6f};
    cooking_pot.uniform.transform.translation = {-0.1f, -0.3f, 0};
    cooking_pot.uniform.transform.scaling     = 0.43f;

    spoon               = mesh_load_file_obj("scenes/sources/particles_trajectory/sprites/assets/spoon.obj");
    spoon.shader        = shader;
    spoon.uniform.color = {0.9f, 0.8f, 0.6f};
    spoon.uniform.transform.translation = {-0.1f, -0.3f, 0};
    spoon.uniform.transform.scaling     = 0.43f;

#ifdef SOLUTION
    liquid_surface                 = mesh_primitive_disc(0.73f,{0,0,0},{0,1,0},60);
    liquid_surface.shader          = shader;
    liquid_surface.uniform.color   = {0.5f,0.6f,0.8f};
    liquid_surface.uniform.shading = {0.7f, 0.3f, 0.0f, 128};
#endif
}


/** This function is called before the beginning of the animation loop
    It is used to initialize all part-specific data */
void scene_model::setup_data(std::map<std::string,GLuint>& shaders, scene_structure& scene, gui_structure& gui)
{
    load_decoration_meshes(shaders["mesh"]);

    bubble = mesh_primitive_sphere(0.03f);
    bubble.shader = shaders["mesh"];

    sprite = mesh_primitive_quad();
    sprite.shader = shaders["mesh"];
    sprite.uniform.color = {1,1,1};
    sprite.uniform.shading = {1,0,0};
    sprite.uniform.transform.scaling = 0.75f;
    sprite.texture_id = create_texture_gpu( image_load_png("scenes/sources/particles_trajectory/sprites/assets/smoke.png") );


    scene.camera.scale = 5.0f;
    scene.camera.orientation = rotation_from_axis_angle_mat3({0,1,0},3.14f/4.0f)*rotation_from_axis_angle_mat3({1,0,0},-3.14f/8.0f);
    gui.show_frame_worldspace = true;
    gui.show_frame_camera = false;

#ifdef SOLUTION
    timer_bubble.periodic_event_time_step = 0.1f;
    timer_sprite.periodic_event_time_step = 0.02f;
#else
    timer_bubble.periodic_event_time_step = 0.25f;
    timer_sprite.periodic_event_time_step = 0.5f;
#endif
}

#ifdef SOLUTION
particle_structure create_new_bubble(float time)
{
    particle_structure particle;
    particle.t0 = time;

    float const theta  = rand_interval(0.0f, 2*3.14f);
    float const radius = rand_interval(0.0f, 0.7f);
    particle.p0     = radius*vec3(std::cos(theta), 0.25, std::sin(theta));
    particle.radius = rand_interval(0,3);
    particle.phase  = rand_interval(0.0f, 2*3.14f);
    particle.color  = {0.5f+rand_interval(0,0.2f),0.6f+rand_interval(0,0.2f),1.0f-rand_interval(0,0.2f)};

    particle.trajectory = curve_dynamic_drawable(20);
    particle.trajectory.uniform.color = vec3{0,0,1};

    return particle;
}

particle_structure create_new_sprite(float time)
{
    particle_structure particle;
    particle.t0 = time;

    const float theta  = rand_interval(0.0f, 2*3.14f);
    particle.p0 = 0.5f*vec3(std::cos(theta), 0.0f, std::sin(theta))+vec3(0,0.25f,0);

    particle.trajectory = curve_dynamic_drawable(20);
    particle.trajectory.uniform.color = vec3{0,0,1};

    return particle;
}


vec3 compute_bubble_position(particle_structure const& particle, float const time)
{
    const float t = time-particle.t0; // local time for the particle since its creation
    const float theta = t;

    // Displacement of the particle
    const float x = 0.15f*std::cos(theta*5+particle.phase);
    const float y = (10-particle.radius)/7.0f*t;                 // small particles move faster
    const float z = 0.15f*std::sin(theta*5+particle.phase);

    const vec3 p = particle.p0 + vec3(x,y,z);
    return p;
}

vec3 compute_sprite_position(particle_structure const& particle, float const time)
{
    const float t = time-particle.t0; // local time for the particle since its creation

    // Displacement of the particle
    const float theta = std::atan2(particle.p0.x, particle.p0.z);
    const float x = t/2*std::sin(theta);
    const float y = -5*(t/3)*(t/3)+2.5f*(t/3);
    const float z = t/2*std::cos(theta);

    const vec3 p = particle.p0 + vec3(x,y,z);
    return p;
}
#else
particle_structure create_new_bubble(float time)
{
    // Code to be filled and adapted appropriately
    //
    // Basic initialization ...
    particle_structure particle;
    particle.t0 = time;
    particle.p0 = {0,0,0};

    return particle;
}
particle_structure create_new_sprite(float time)
{
    // Code to be filled and adapted appropriately
    //
    // Basic initialization ...
    particle_structure particle;
    particle.t0 = time;
    particle.p0 = {0,0,0};

    return particle;
}
#endif

/** This function is called at each frame of the animation loop.
    It is used to compute time-varying argument and perform data data drawing */
void scene_model::frame_draw(std::map<std::string,GLuint>& shaders, scene_structure& scene, gui_structure& )
{
    set_gui();

    timer_bubble.update();
    float const time = timer_bubble.t;

    // Display decoration
    if(gui_scene.display_decoration){
        draw(cooking_pot, scene.camera);
        draw(spoon, scene.camera);
#ifdef SOLUTION
        draw(liquid_surface, scene.camera);
#endif
    }

    // If a new bubble need to be created
    if( timer_bubble.event )
        particles_bubble.push_back(create_new_bubble(time));

#ifdef SOLUTION
    // Update and display the bubble
    for(particle_structure& particle : particles_bubble)
    {
        vec3 const p = compute_bubble_position(particle, time);

        bubble.uniform.transform.translation = p;
        bubble.uniform.transform.scaling = particle.radius;
        bubble.uniform.color = particle.color;
        particle.trajectory.add_point(p);

        if(gui_scene.display_bubbles)
            draw(bubble, scene.camera);
        if(gui_scene.display_trajectory_bubble)
            particle.trajectory.draw(shaders["curves"], scene.camera);

    }
#else
    // Compute trajectory and display the bubbles
    for(particle_structure& particle : particles_bubble)
    {
        // Correct and adapt this code ...
        vec3 const p = particle.p0 + vec3(0,time-particle.t0,0);
        bubble.uniform.transform.translation = p;

        draw(bubble, scene.camera);
        particle.trajectory.add_point(p);
    }
#endif


    // If a new sprite need to be created
    timer_sprite.update();
    if( timer_sprite.event )
        particles_sprite.push_back( create_new_sprite(time) );

#ifdef SOLUTION
    // Update and display the sprite
    if(gui_scene.sprite_as_billboards){
        glEnable(GL_BLEND);
        glDepthMask(false);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
    else
        glDisable(GL_BLEND);
    for(particle_structure& particle : particles_sprite)
    {
        vec3 const p = compute_sprite_position(particle, time);

        sprite.uniform.transform.translation = p;
        float const alpha = (time-particle.t0)/3.0f;
        if(gui_scene.sprite_as_billboards)
            sprite.uniform.color_alpha = (1-alpha)*std::sqrt(alpha);
        particle.trajectory.add_point(p);

        if(gui_scene.sprite_as_billboards){
            sprite.uniform.transform.rotation = scene.camera.orientation;
        }
        if(gui_scene.display_sprites)
            draw(sprite, scene.camera);
        if(gui_scene.display_trajectory_sprite)
            particle.trajectory.draw(shaders["curves"], scene.camera);

    }
    glDepthMask(true);
#else
    // Compute trajectory and display the sprites
    for(particle_structure& particle : particles_sprite)
    {
        // Correct and adapt this code ...
        //

        // Prepare for transparent element drawing
        glEnable(GL_BLEND);
        glDepthMask(false); // deactivate zbuffer writing
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        vec3 const p = particle.p0 + vec3(0,0,time-particle.t0);
        sprite.uniform.transform.translation = p;

        draw(sprite, scene.camera);
        particle.trajectory.add_point(p);
        glDepthMask(true); // Important: reactivate writing in ZBuffer for future drawing
    }
#endif

#ifdef SOLUTION
    for(auto it = particles_bubble.begin(); it!=particles_bubble.end(); ++it)
        if( time-it->t0 > 2)
            it = particles_bubble.erase(it);

    for(auto it = particles_sprite.begin(); it!=particles_sprite.end(); ++it)
        if( time-it->t0 > 3)
            it = particles_sprite.erase(it);
#else
    // Do not forget to erase particles after some time
#endif

}



void scene_model::set_gui()
{
    // Start/Stop animation
    const bool start = ImGui::Button("Start"); ImGui::SameLine();
    const bool stop  = ImGui::Button("Stop");
    if(start) {timer_bubble.start(); timer_sprite.start();}
    if(stop) {timer_bubble.stop(); timer_sprite.stop();}

    // Speed of the animation
    ImGui::SliderFloat("Time scale", &timer_bubble.scale, 0.05f, 2.0f);
    timer_sprite.scale = timer_bubble.scale;

    // Interval of time between creation of a new particle
    ImGui::SliderFloat("Timer event bubbles", &timer_bubble.periodic_event_time_step, 0.01f, 0.5f);
    ImGui::SliderFloat("Timer event sprite", &timer_sprite.periodic_event_time_step, 0.01f, 0.5f);

    ImGui::Checkbox("Display decoration",&gui_scene.display_decoration); ImGui::SameLine();
#ifdef SOLUTION
    ImGui::Checkbox("Display bubbles",&gui_scene.display_bubbles);
    ImGui::Checkbox("Display sprites",&gui_scene.display_sprites); ImGui::SameLine();
    ImGui::Checkbox("Sprite as billboard",&gui_scene.sprite_as_billboards);

    ImGui::Checkbox("Display trajectory bubbles",&gui_scene.display_trajectory_bubble);
    ImGui::Checkbox("Display trajectory sprites",&gui_scene.display_trajectory_sprite);
#endif
}



#endif
